import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: _titulo(),
        backgroundColor: Colors.white,
        body: _corpo(),
      ),
    );
  }

  _titulo() {
    return AppBar(
      title: Text("Emerald: só Carrões"),
      centerTitle: true,
      backgroundColor: Color(0xff427843),
    );
  }

  _corpo() {
    return PageView(
      children: <Widget>[
        carro('mercedez.jpg', 'Mercedes-Benz Classe S'),
        carro('toyota.jpeg', 'Toyota Highlander'),
        // Adicione mais carros aqui
      ],
    );
  }

  Widget carro(String nomeFoto, String nomeCarro) {
    return Column(
      children: <Widget>[
        _foto(nomeFoto),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(
            nomeCarro,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(
            _descricaoCarro(nomeCarro),
            style: TextStyle(
              fontSize: 16,
            ),
          ),
        ),
      ],
    );
  }

  Widget _foto(String nomeFoto) {
    return Image.asset(
      "assets/images/$nomeFoto",
      height: 300,
      width: 300,
      fit: BoxFit.contain,
    );
  }

  String _descricaoCarro(String nomeCarro) {
    switch (nomeCarro) {
      case 'Mercedes-Benz Classe S':
        return 'Este sedã de luxo é sinônimo de elegância e desempenho. Com um motor potente, interior de couro requintado e tecnologia de ponta, o Mercedes-Benz Classe S oferece uma experiência de condução de alto nível que combina conforto e sofisticação.';
      case 'Toyota Highlander':
        return 'O Toyota Highlander é o veículo ideal para famílias que buscam espaço e versatilidade. Com capacidade para até oito passageiros e amplo espaço de carga, este SUV oferece segurança, eficiência e uma série de recursos de entretenimento para viagens em família.';
      // Adicione descrições para outros carros aqui
      default:
        return '';
    }
  }
}
