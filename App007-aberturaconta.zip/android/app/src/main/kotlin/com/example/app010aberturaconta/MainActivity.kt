package com.example.app010aberturaconta

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
