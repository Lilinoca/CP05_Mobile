import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primaryColor: Colors.blue),
      home: TelaInicial(),
    );
  }
}

class TelaInicial extends StatefulWidget {
  const TelaInicial({Key? key}) : super(key: key);

  @override
  _TelaInicialState createState() => _TelaInicialState();
}

class _TelaInicialState extends State<TelaInicial> {
  TextEditingController nomeController = TextEditingController();
  TextEditingController idadeController = TextEditingController();

  String dropdownGenero = "Masculino";
  String dropdownEscolaridade = "Ensino Médio";
  double valorSlider = 200.00;
  bool brasileiroSwitch = false;

  String confirmacao = "";

  void _confirmar() {
    setState(() {
      confirmacao =
          "Nome: ${nomeController.text}\nIdade: ${idadeController.text}\nGênero: $dropdownGenero\nEscolaridade: $dropdownEscolaridade\nLimite: R\$ ${valorSlider.toStringAsFixed(2)}\nBrasileiro: $brasileiroSwitch";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Abertura de Conta",
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
        backgroundColor: Color(0xfff2ac42),
      ),
      body: _body(),
    );
  }

  Widget _body() {
    return SingleChildScrollView(
      child: Container(
        padding: EdgeInsets.all(15.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            _campoNome(),
            SizedBox(height: 10),
            _campoIdade(),
            SizedBox(height: 10),
            _dropdownGenero(),
            SizedBox(height: 10),
            _dropdownEscolaridade(),
            SizedBox(height: 30),
            _limiteSlider(),
            SizedBox(height: 16),
            _textoSlider(),
            _braileiroSwitch(),
            SizedBox(height: 16),
            _button(),
            SizedBox(height: 16),
            _confirmacao(),
          ],
        ),
      ),
    );
  }

  Widget _campoNome() {
    return TextField(
      keyboardType: TextInputType.text,
      decoration: InputDecoration(
        labelText: 'Digite seu nome completo',
        labelStyle: TextStyle(color: Colors.blue),
      ),
      textAlign: TextAlign.center,
      style: TextStyle(color: Colors.orange, fontSize: 20.0),
      controller: nomeController,
    );
  }

  Widget _campoIdade() {
    return TextField(
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        labelText: 'Digite sua idade',
        labelStyle: TextStyle(color: Colors.blue),
      ),
      textAlign: TextAlign.center,
      style: TextStyle(color: Colors.orange, fontSize: 20.0),
      controller: idadeController,
    );
  }

  Widget _dropdownGenero() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text("Gênero",
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
        DropdownButton<String>(
          value: dropdownGenero,
          items: <String>['Masculino', 'Feminino'].map((String value) {
            return DropdownMenuItem<String>(
              value: value,
              child: Text(value),
            );
          }).toList(),
          onChanged: (String? valorSelecionado) {
            setState(() {
              dropdownGenero = valorSelecionado!;
            });
          },
        ),
      ],
    );
  }

  Widget _dropdownEscolaridade() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text("Escolaridade",
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
        DropdownButton<String>(
          value: dropdownEscolaridade,
          items: <String>['Ensino Médio', 'Graduação', 'Pós-graduação', 'MBA']
              .map((String value) {
            return DropdownMenuItem<String>(
              value: value,
              child: Text(value),
            );
          }).toList(),
          onChanged: (String? valorSelecionado) {
            setState(() {
              dropdownEscolaridade = valorSelecionado!;
            });
          },
        ),
      ],
    );
  }

  Widget _limiteSlider() {
    return Slider(
      value: valorSlider,
      min: 0,
      max: 10000,
      divisions: 20,
      label: valorSlider.round().toString(),
      onChanged: (double value) {
        setState(() {
          valorSlider = value;
        });
      },
    );
  }

  Widget _textoSlider() {
    return Text(
      "Limite: " +
          (valorSlider > 5000
              ? 'Acima de R\$ 5000'
              : valorSlider.toStringAsFixed(2)),
      style: TextStyle(
        color: Colors.blue,
        fontSize: 15,
        fontWeight: FontWeight.bold,
      ),
    );
  }

  Widget _braileiroSwitch() {
    return SwitchListTile(
      title: Text("Brasileiro",
          style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
      value: brasileiroSwitch,
      onChanged: (bool value) {
        setState(() {
          brasileiroSwitch = value;
        });
      },
    );
  }

  Widget _button() {
    return Container(
      width: 200,
      height: 40,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          primary: Color(0xffebb35c),
        ),
        onPressed: () {
          _confirmar();
        },
        child: Text(
          "Confirmar",
          style: TextStyle(
            color: Colors.white,
            fontSize: 24,
          ),
        ),
      ),
    );
  }

  Widget _confirmacao() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Text(
        confirmacao,
        textAlign: TextAlign.center,
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
          color: Colors.blue,
        ),
      ),
    );
  }
}
