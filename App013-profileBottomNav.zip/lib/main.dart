import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Home(),
    );
  }
}

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int _currentIndex = 0;

  final List<Widget> _pages = [
    InformacaoPessoalPage(),
    ExperienciasPage(),
    FormacaoPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Perfil Lina Maria"),
        centerTitle: true,
        backgroundColor: Colors.black,
      ),
      body: _pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: "Informação Pessoal",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.work),
            label: "Experiências",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.school),
            label: "Formação",
          ),
        ],
      ),
    );
  }
}

class InformacaoPessoalPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: CircleAvatar(
              radius: 80,
              backgroundImage: NetworkImage(
                'https://avatars.githubusercontent.com/Lilinoca',
              ),
            ),
          ),
          SizedBox(height: 20),
          Text(
            "Informação Pessoal",
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 10),
          Text(
            'Nome Completo: Lina Maria Fazia Teixeira \nData de Nascimento: 28/04/1982 \nNacionalidade: Brasileira \nEstado Civil: Solteira \nEndereço: Rua Maranhão - Higienópolis - SP',
            style: TextStyle(
              fontSize: 20,
            ),
          ),
        ],
      ),
    );
  }
}

class ExperienciasPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Experiências",
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 10),
          Text(
            "2020 - 2021: Coordenadora de Customer Success na Cultural Care Au Pair Brasil /n2019 - 2020: Supervisora de E-commerce para a Acquamarine Eyewear Brasil /n2013 - 2018: Proprietária do Espaço 946 Hostel - Bar em São Paulo, @espaco946 /n2011: Sales Coordinator at GDS International - Sidney, Australia",
            style: TextStyle(
              fontSize: 18,
            ),
          ),
        ],
      ),
    );
  }
}

class FormacaoPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Formação",
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 10),
          Text(
            "E-commerce e Modelo de Negócios Digitais - FGV - 2019 \nMaster em International Relations Management - ASERI, Milano - 2009 \nBacharel em Relações Internacionais pela FAAP, 2003 a 2007 \n2o grau no Colégio Mackenzie e na Kimberly High School nos EUA - 1999 ",
            style: TextStyle(
              fontSize: 18,
            ),
          ),
        ],
      ),
    );
  }
}
