package com.example.app011profiledrawer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
