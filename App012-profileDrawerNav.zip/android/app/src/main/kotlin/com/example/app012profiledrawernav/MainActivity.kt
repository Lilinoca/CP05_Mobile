package com.example.app012profiledrawernav

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
