import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Perfil Lina Maria',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
        backgroundColor: Colors.black,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              accountName: Text('Lina Maria Fazia Teixeira'),
              accountEmail: Text('linamariaft@yahoo.com.br'),
              currentAccountPicture: CircleAvatar(
                backgroundImage: AssetImage('assets/images/Lilinoca.jpeg'),
              ),
              decoration: BoxDecoration(
                color: Colors.black,
              ),
            ),
            ListTile(
              title: Text('Pessoal'),
              leading: Icon(Icons.person),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => PessoalScreen()));
              },
            ),
            ListTile(
              title: Text('Formação'),
              leading: Icon(Icons.school),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => FormacaoScreen()));
              },
            ),
            ListTile(
              title: Text('Experiência'),
              leading: Icon(Icons.work),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ExperienciaScreen()));
              },
            ),
          ],
        ),
      ),
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(100.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(
                'Bem-vindo à tela Home do perfil de Lina Maria!',
                style: TextStyle(fontSize: 20),
              ),
              Text(
                'Utilize o Menu acima para navegar!',
                style: TextStyle(fontSize: 20),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class PessoalScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Informação Pessoal'),
        backgroundColor: Colors.black,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center(
          child: Text(
            'Nome Completo: Lina Maria Fazia Teixeira \nData de Nascimento: 28/04/1982 \nNacionalidade: Brasileira \nEstado Civil: Solteira \nEndereço: Rua Maranhão - Higienópolis - SP',
            style: TextStyle(fontSize: 18),
          ),
        ),
      ),
    );
  }
}

class FormacaoScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Formação'),
        backgroundColor: Colors.black,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center(
          child: Text(
            'E-commerce e Modelo de Negócios Digitais - FGV - 2019\n'
            'Master em International Relations Management - ASERI, Milano - 2009\n'
            'Bacharel em Relações Internacionais pela FAAP, 2003 a 2007\n'
            '2o grau no Colégio Mackenzie e na Kimberly High School nos EUA - 1999',
            style: TextStyle(fontSize: 18),
          ),
        ),
      ),
    );
  }
}

class ExperienciaScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Experiência'),
        backgroundColor: Colors.black,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center(
          child: Text(
            "2020 - 2021: Coordenadora de Customer Success na Cultural Care Au Pair Brasil\n"
            "2019 - 2020: Supervisora de E-commerce para a Acquamarine Eyewear Brasil\n"
            "2013 - 2018: Proprietária do Espaço 946 Hostel - Bar em São Paulo, @espaco946\n"
            "2011: Sales Coordinator at GDS International - Sidney, Australia",
            style: TextStyle(fontSize: 18),
          ),
        ),
      ),
    );
  }
}
