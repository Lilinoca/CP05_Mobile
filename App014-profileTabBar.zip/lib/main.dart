import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: TabBarApp(),
    );
  }
}

class TabBarApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.black,
          title: Text(
            'Perfil Lina Maria',
            style: TextStyle(
              color: Colors.white,
            ),
          ),
          centerTitle: true,
          bottom: TabBar(
            tabs: [
              Tab(
                text: "Pessoal",
                icon: Icon(Icons.person, color: Colors.white),
              ),
              Tab(
                text: "Formação",
                icon: Icon(Icons.school, color: Colors.white),
              ),
              Tab(
                text: "Experiência",
                icon: Icon(Icons.work, color: Colors.white),
              ),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            PessoalTab(),
            FormacaoTab(),
            ExperienciaTab(),
          ],
        ),
      ),
    );
  }
}

class PessoalTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Text(
          'Nome Completo: Lina Maria Fazia Teixeira \nData de Nascimento: 28/04/1982 \nNacionalidade: Brasileira \nEstado Civil: Solteira \nEndereço: Rua Maranhão - Higienópolis - SP',
          style: TextStyle(
            fontSize: 20,
          ),
        ),
      ),
    );
  }
}

class FormacaoTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Text(
          'E-commerce e Modelo de Negócios Digitais - FGV - 2019 \nMaster em International Relations Management - ASERI, Milano - 2009 \nBacharel em Relações Internacionais pela FAAP, 2003 a 2007 \n2o grau no Colégio Mackenzie e na Kimberly High School nos EUA - 1999',
          style: TextStyle(
            fontSize: 20,
          ),
        ),
      ),
    );
  }
}

class ExperienciaTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Text(
          '''2020 - 2021: Coordenadora de Customer Success na Cultural Care Au Pair Brasil 
2019 - 2020: Supervisora de E-commerce para a Acquamarine Eyewear Brasil
2013 - 2018: Proprietária do Espaço 946 Hostel - Bar em São Paulo, @espaco946
2011: Sales Coordinator at GDS International - Sidney, Australia''',
          style: TextStyle(
            fontSize: 20,
          ),
        ),
      ),
    );
  }
}
