package com.example.app014profiletabbar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
