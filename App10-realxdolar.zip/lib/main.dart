import 'package:flutter/material.dart';

//pegar IMC como modelo
void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TelaInicial();
  }
}

class TelaInicial extends StatefulWidget {
  const TelaInicial({Key? key}) : super(key: key);

  @override
  _TelaInicialState createState() => _TelaInicialState();
}

class _TelaInicialState extends State<TelaInicial> {
  TextEditingController valorController = TextEditingController();
  double valor = 0.0;
  String origem = 'Real';
  String destino = 'Real';
  String resultado = '';

  void converter() {
    double res = 0.0;

    if (origem == 'Dólar' && destino == 'Dólar') {
      res = valor * 1;
    } else if (origem == 'Dólar' && destino == 'Real') {
      res = valor * 4.93;
    } else if (origem == 'Dólar' && destino == 'Euro') {
      res = valor * 0.93;
    } else if (origem == 'Real' && destino == 'Real') {
      res = valor * 1;
    } else if (origem == 'Real' && destino == 'Dólar') {
      res = valor / 0.20; // Correção da taxa de câmbio para Real para Dólar.
    } else if (origem == 'Real' && destino == 'Euro') {
      res =
          valor / 0.19; // Taxa de câmbio fictícia, ajuste conforme necessário.
    } else if (origem == 'Euro' && destino == 'Euro') {
      res = valor * 1;
    } else if (origem == 'Euro' && destino == 'Dólar') {
      res =
          valor / 1.07; // Taxa de câmbio fictícia, ajuste conforme necessário.
    } else if (origem == 'Euro' && destino == 'Real') {
      res =
          valor / 5.30; // Taxa de câmbio fictícia, ajuste conforme necessário.
    }

    setState(() {
      resultado = 'Resultado: ${res.toStringAsFixed(2)}';
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primaryColor: Colors.green),
      home: Scaffold(
        appBar: AppBar(
          title: Text("Conversor de Moedas: Dólar, Real & Euro"),
          centerTitle: true,
        ),
        body: _body(),
      ),
    );
  }

  _body() {
    return Container(
      width: double.infinity,
      color: Colors.white10,
      child: Column(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          _campoInput(),
          _campoDe(),
          _campoPara(),
          _button(),
          _texto(resultado), // Alterei para exibir o resultado.
        ],
      ),
    );
  }

  _campoInput() {
    return TextField(
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
          labelText: "Digite aqui o valor",
          labelStyle: TextStyle(color: Colors.green)),
      textAlign: TextAlign.center,
      style: TextStyle(color: Colors.black, fontSize: 25.0),
      controller: valorController,
      onChanged: (value) {
        setState(() {
          valor = double.tryParse(value) ?? 0.0;
        });
      },
    );
  }

  String dropdownValorOrigem =
      'Real'; // Adicionei dropdownValorOrigem e dropdownValorDestino.
  String dropdownValorDestino = 'Real';

  _campoDe() {
    return DropdownButton<String>(
      value: dropdownValorOrigem,
      icon: const Icon(Icons.arrow_downward),
      iconSize: 24,
      elevation: 16,
      style: const TextStyle(color: Colors.deepPurple),
      underline: Container(
        height: 2,
        color: Colors.deepPurpleAccent,
      ),
      onChanged: (String? newValue) {
        setState(() {
          dropdownValorOrigem = newValue!;
        });
      },
      items: <String>['Real', 'Dólar', 'Euro']
          .map<DropdownMenuItem<String>>((String value) {
        return DropdownMenuItem<String>(
          value: value,
          child: Text(value),
        );
      }).toList(),
    );
  }

  _campoPara() {
    return DropdownButton<String>(
      value: dropdownValorDestino,
      icon: const Icon(Icons.arrow_downward),
      iconSize: 24,
      elevation: 16,
      style: const TextStyle(color: Colors.deepPurple),
      underline: Container(
        height: 2,
        color: Colors.deepPurpleAccent,
      ),
      onChanged: (String? newValue) {
        setState(() {
          dropdownValorDestino = newValue!;
        });
      },
      items: <String>['Real', 'Dólar', 'Euro']
          .map<DropdownMenuItem<String>>((String value) {
        return DropdownMenuItem<String>(
          value: value,
          child: Text(value),
        );
      }).toList(),
    );
  }

  _button() {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        primary: Colors.green,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(100.0),
        ),
      ),
      onPressed: () {
        converter();
      },
      child: Text(
        "Converter",
        style: TextStyle(
          color: Colors.white,
          fontSize: 20,
        ),
      ),
    );
  }

  _texto(String exibicaoConversao) {
    return Text(exibicaoConversao); // Aqui você exibe o resultado da conversão.
  }
}
