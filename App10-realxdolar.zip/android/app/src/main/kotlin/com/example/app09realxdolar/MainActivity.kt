package com.example.app09realxdolar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
