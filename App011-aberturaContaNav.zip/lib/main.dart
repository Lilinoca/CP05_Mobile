import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: InfoScreen(),
    );
  }
}

class InfoScreen extends StatefulWidget {
  @override
  _InfoScreenState createState() => _InfoScreenState();
}

class _InfoScreenState extends State<InfoScreen> {
  final TextEditingController nomeController = TextEditingController();
  final TextEditingController idadeController = TextEditingController();
  String generoSelecionado = 'Masculino';
  String escolaridadeSelecionada = 'Ensino Médio';
  double limiteSlider = 1000.0;
  bool brasileiro = true;

  final List<String> escolaridades = [
    'Ensino Médio',
    'Graduação',
    'Pós-Graduação',
    'MBA'
  ];

  void _exibirInfo() {
    final String nome = nomeController.text;
    final String idade = idadeController.text;

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => InfoInserida(
          nome: nome,
          idade: idade,
          genero: generoSelecionado,
          escolaridade: escolaridadeSelecionada,
          limite: limiteSlider,
          brasileiro: brasileiro,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Abertura de Conta',
          style: TextStyle(
            fontSize: 24,
          ),
        ),
        centerTitle: true,
        backgroundColor: Color(0xfff4a329),
      ),
      body: Padding(
        padding: const EdgeInsets.all(18.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            _campo('Digite seu nome', nomeController),
            _campo('Digite sua idade', idadeController),
            _dropdownGenero(),
            _dropdownEscolaridade(),
            _sliderLimite(),
            _switchNacionalidade(),
            SizedBox(height: 18),
            ElevatedButton(
              onPressed: () {
                _exibirInfo();
              },
              child: Text('Confirmar'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _campo(String title, TextEditingController controller) {
    return TextField(
      decoration: InputDecoration(
        labelText: title,
      ),
      controller: controller,
    );
  }

  Widget _dropdownGenero() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text('Gênero:'),
          DropdownButton<String>(
            value: generoSelecionado,
            items: ['Masculino', 'Feminino'].map((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
            onChanged: (String? valorSelecionado) {
              setState(() {
                generoSelecionado = valorSelecionado!;
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _dropdownEscolaridade() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text("Escolaridade:"),
          DropdownButton<String>(
            value: escolaridadeSelecionada,
            items: escolaridades.map((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
            onChanged: (String? valorSelecionado) {
              setState(() {
                escolaridadeSelecionada = valorSelecionado!;
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _sliderLimite() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text("Limite Desejado:"),
          Slider(
            value: limiteSlider,
            min: 0,
            max: 5000,
            divisions: 100,
            label: (limiteSlider > 3000)
                ? 'Atenção, acima de 3 mil ($limiteSlider)'
                : limiteSlider.round().toString(),
            onChanged: (double value) {
              setState(() {
                limiteSlider = value;
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _switchNacionalidade() {
    return Container(
      child: Row(
        children: <Widget>[
          Text('Brasileiro(a)?'),
          SizedBox(width: 17),
          Switch(
            value: brasileiro,
            onChanged: (value) {
              setState(() {
                brasileiro = value;
              });
            },
          ),
        ],
      ),
    );
  }
}

class InfoInserida extends StatelessWidget {
  final String nome;
  final String idade;
  final String genero;
  final String escolaridade;
  final double limite;
  final bool brasileiro;

  InfoInserida({
    required this.nome,
    required this.idade,
    required this.genero,
    required this.escolaridade,
    required this.limite,
    required this.brasileiro,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Confirmação dos Dados',
          style: TextStyle(
            fontSize: 24,
          ),
        ),
        centerTitle: true,
        backgroundColor: Color(0xfff4a329),
      ),
      body: Padding(
        padding: const EdgeInsets.all(18.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Text('Nome completo: $nome'),
            Text('Idade: $idade'),
            Text('Gênero: $genero'),
            Text('Escolaridade: $escolaridade'),
            Text('Limite: $limite'),
            Text('Nacionalidade: ${brasileiro ? 'Brasileira' : 'Estrangeira'}'),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Voltar'),
            ),
          ],
        ),
      ),
    );
  }
}
