package com.example.app011aberturaconta

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
