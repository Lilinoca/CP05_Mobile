import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: _titulo(),
        backgroundColor: Colors.white,
        body: _corpo(),
      ),
    );
  }

  AppBar _titulo() {
    return AppBar(
      title: Text("Vagas em TI"),
      centerTitle: true,
      backgroundColor: Color(0xff5967ea),
    );
  }

  ListView _corpo() {
    return ListView(
      children: <Widget>[
        vaga('Desenvolvedor Full Stack Júnior - Florianópolis - SC',
            'Estamos em busca de um desenvolvedor Full Stack Júnior para se juntar à nossa equipe de desenvolvimento. Se você é apaixonado por tecnologia, possui habilidades em front-end e back-end, e deseja crescer em um ambiente colaborativo, essa vaga é para você! Regime CLT, salário a combinar.'),
        vaga('Analista de Suporte Técnico - Rio de Janeiro - RJ',
            'Procuramos um analista de suporte técnico para fornecer suporte de alto nível aos nossos clientes. Se você possui conhecimentos sólidos em sistemas operacionais, redes e solução de problemas, junte-se a nós para fazer parte da nossa equipe comprometida em oferecer excelência em suporte. CLT, salário: R\$\5000,00.'),
        vaga('Estágio em Desenvolvimento Web - Belo Horizonte - MG',
            'Oferecemos uma oportunidade de estágio em desenvolvimento web para estudantes apaixonados por programação. Trabalhe em projetos reais, aprenda com profissionais experientes e adquira experiência valiosa para impulsionar sua carreira futura. Contrato de 1 ano com bolsa auxílio.'),
        vaga('Gerente de Projetos de TI Sênior - São Paulo - SP',
            'Estamos em busca de um gerente de projetos de TI sênior para liderar nossa equipe de gerenciamento de projetos. Se você possui uma sólida experiência em liderança, é apaixonado por entregar soluções de TI de alta qualidade e tem um histórico comprovado de sucesso em gerenciamento de projetos, queremos ouvir de você. Salário competitivo e diversos benefícios.'),
      ],
    );
  }

  Widget vaga(String titulo, String descricao) {
    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.all(15.0),
          child: Text(
            titulo,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(15.0),
          child: Text(
            descricao,
            style: TextStyle(
              fontSize: 16,
            ),
          ),
        ),
      ],
    );
  }
}
