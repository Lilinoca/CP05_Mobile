package com.example.app08vagas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
