package com.example.app06__numeroaleatorio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
