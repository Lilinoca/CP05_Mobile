import 'package:flutter/material.dart';
import 'dart:math';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TelaInicial();
  }
}

class TelaInicial extends StatefulWidget {
  const TelaInicial({Key? key}) : super(key: key);

  @override
  _TelaInicialState createState() => _TelaInicialState();
}

class _TelaInicialState extends State<TelaInicial> {
  String numero = ""; // Variável para armazenar o número a ser exibido

  void _descobrirNumero() {
    setState(() {
      int numeroAdivinhado =
          Random().nextInt(11); // Gera um número aleatório entre 0 e 10
      numero =
          "O número que você pensou foi $numeroAdivinhado"; // Define a mensagem com o número gerado
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text("Adivinhador de Números"),
          backgroundColor: Colors.black,
          centerTitle: true,
        ),
        body: _body(),
      ),
    );
  }

  Widget _body() {
    return Container(
      width: double.infinity,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          _image(),
          SizedBox(height: 20), // Adiciona um espaço entre a imagem e o título
          Text(
            "Pense em um número de 0 a 10", // Título
            style: TextStyle(
              color: Colors.black,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          _text(), // Chama o método _text() para exibir a mensagem
          _button(),
        ],
      ),
    );
  }

  Widget _image() {
    return Center(
      child: Image.network(
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTrrBe4WTU0l86bRxSN9teXIcnjwDPqsNwhqveLxaAQ3A&s',
        height: 300,
        width: 300,
      ),
    );
  }

  Widget _text() {
    return Text(
      numero, // Exibe a mensagem com o número gerado
      style: TextStyle(
        color: Colors.red,
        fontSize: 22,
      ),
    );
  }

  Widget _button() {
    return Container(
      width: 200,
      height: 40,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          primary: Colors.black,
        ),
        onPressed: () {
          _descobrirNumero(); // Chama o método para descobrir o número
        },
        child: Text(
          "Descobrir",
          style: TextStyle(
            color: Colors.white,
            fontSize: 24,
          ),
        ),
      ),
    );
  }
}
